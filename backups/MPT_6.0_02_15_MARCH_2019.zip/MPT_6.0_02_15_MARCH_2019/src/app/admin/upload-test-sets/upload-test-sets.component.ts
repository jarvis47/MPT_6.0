import { Component, OnInit } from '@angular/core';
import {AdminService} from '../../services/admin.service';
import { Http } from '@angular/http'
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {UploadTestDetails} from '../../models/uploadTestDetails';
import {FileUploadedModel} from '../../models/file-uploaded-model';
import { Batch } from '../../models/batch';
const url = "http://localhost:8080/fileupload";

@Component({
  selector: 'app-upload-test-sets',
  templateUrl: './upload-test-sets.component.html',
  styleUrls: ['./upload-test-sets.component.css']
})
export class UploadTestSetsComponent implements OnInit 
{
  uploadTestPaperSetForm:FormGroup;
  batchData:Batch[]=[];
  ngOnInit() {
     //GET BATCH NAME AND ID FROM THE DATABASE
     this.adminService
     .getBatch()
     .subscribe((data)=>{
       this.batchData=data;
     });
  }
  constructor(private adminService:AdminService,private http:Http) { 
    //SET FORM CONTROLS
    this.uploadTestPaperSetForm=new FormGroup({
      selectedTestPaperSetFile:new FormControl(''),
      selectedBatch:new FormControl(''),
      selectedModule:new FormControl(''),
      selectedSetNumber:new FormControl(''),
      testType:new FormControl('')
  });
     
  }
  location:string[]=['Chennai'];
  
  subLocation:string[]=['SIPCOT','MIPL','PCT'];
  
  module:string[]=['Module 1','Module 2','Module 3','Module 4','Module 5'];

  selectedFile;
  onFileSelect(event)
  {
   this.selectedFile = event.target.files[0];
  
  }
  //Validators
  emptyFile:boolean;
  emptyLocation:boolean;
  emptySubLocation:boolean;
  emptyBatchName:boolean;
  emptyModuleName:boolean;

 onSubmit()
 {
    //create an instance of model
  let uploadTestDetailsModel =new UploadTestDetails();
  //let fileUploadedModel=new FileUploadedModel();
  
  //set form data into that
   let selectedBatch=this.uploadTestPaperSetForm.controls['selectedBatch'].value;
   
   //batch name
   uploadTestDetailsModel.batchName=selectedBatch.batchName;

   //batch location
   uploadTestDetailsModel.location=selectedBatch.location;

   //batch sublocation
   uploadTestDetailsModel.subLocation=selectedBatch.subLocation;
   
   let selectedModule=this.uploadTestPaperSetForm.controls['selectedModule'].value; 
   uploadTestDetailsModel.module=selectedModule;
   
   let testType=this.uploadTestPaperSetForm.controls['testType'].value; 
   uploadTestDetailsModel.testPaperType=testType;

   //Todays Date 
   uploadTestDetailsModel.dateOfUpload=new Date();

   //set number
   let setNumber=this.uploadTestPaperSetForm.controls['selectedSetNumber'].value; 
   uploadTestDetailsModel.setNumber=setNumber;

   //set test paper name
   let testPaperSetName=selectedBatch.batchName+"_"+testType+"_set_"+setNumber+"_"+selectedModule;

   uploadTestDetailsModel.testPaperSetName=testPaperSetName;

  if(this.selectedFile==null)
  {
    alert("Please select File !!");
  }
  else
  {
    /***********************************************Upload File************************************ */

    this.adminService.uploadFile(this.selectedFile,testPaperSetName,"testPaper")
    .then((modelResponse:FileUploadedModel)=>
    {
      console.log(modelResponse)
    });



   /***************************************save test details in db******************************* */
  
   //Saving details here
  this.adminService.storeTestUploadedSet(uploadTestDetailsModel).then((modelResponse:UploadTestDetails)=>
  {  
    console.log("Response from database : ID now -"+modelResponse._id + "\nDate of upload  : "+modelResponse.dateOfUpload);
    console.log("test paper name : "+modelResponse.testPaperSetName);
    });
 }

 
}

// getBatchNames():string[]
// {
//   console.log(this.batchData)
//   let batchNames:string[]=[];
//   for(let i=0;i<this.batchData.length;i++)
//   {
//     batchNames.push(this.batchData[i].batchName);
//   }
//   return batchNames;
// }

onSelectionBatchOption(b)
{
  console.log(b.batchName);
}

}

import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { TestData } from '../../models/test-data';
import {Candidate} from '../../models/candidate';
import { TestJSON } from '../../models/test-JSON';

type AOA = any[][];

@Component({
	selector: 'app-assign-test-sets',
	templateUrl: './assign-test-sets.component.html',
	styleUrls: ['./assign-test-sets.component.css']
})
export class AssignTestSetsComponent implements OnInit {


	finalTestData: string[][] = [];
	constructor() {

	}
	choosedPaperSet: boolean;
	choosedLabDetails: boolean;
	testAssinedToIndividual: boolean;
	paperSetName: string;
	testAssignedToIndividual: string;

	/********************************************************File Reading*************************************  */

	data: AOA;
	wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
	fileName: string = 'SheetJS.xlsx';

	onChooseLabDetails(evt: any) {
		// wire up file reader 
		const target: DataTransfer = <DataTransfer>(evt.target);
		if (target.files.length !== 1) throw new Error('Cannot use multiple files');
		const reader: FileReader = new FileReader();
		reader.onload = (e: any) => {
			// read workbook 
			const bstr: string = e.target.result;
			const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

			// grab first sheet 
			const wsname: string = wb.SheetNames[0];
			console.log(wsname);
			const ws: XLSX.WorkSheet = wb.Sheets[wsname];

			// save data 
			this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));

			//	console.log(this.data);
		};
		reader.readAsBinaryString(target.files[0]);

		this.choosedLabDetails = true;
	}

	export(): void 
	{

		// generate worksheet 
		
		//const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.finalTestData);
		const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.finalTestJSON(this.assignedTestData));
		console.log(this.finalTestJSON(this.assignedTestData));
		
		// generate workbook and add the worksheet 
		const wb: XLSX.WorkBook = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
		// save to file 
		XLSX.writeFile(wb, this.fileName);
	}

	//*******************************Choose paper set********************************************* */
	paperSetsAvailable: string[] = ["JEE_FULLSTACK_NON_FS_SET_1", "JEE_FULLSTACK_NON_FS_SET_2", "JEE_FULLSTACK_NON_FS_SET_3"];
	selectedSet;
	onChoosePaperSet(event: any) {
		this.paperSetName = event.target.value;
		console.log("paper set :" + this.paperSetName);
		this.choosedPaperSet = true;
	}

	//************************************Assign Test to Particular Uses**************************************

	assignedTestData: TestData[] = [];

	assinedIpAddresses: string[] = [];
	
	//Set Properties into the TestData

	setPropertiesToTestData(row:any[],testData:TestData,candidate:Candidate)
	{
		testData.srNo= <string>row[0];
		testData.testPaperSet=this.paperSetName;
		testData.dateOfAssignment=new Date();
		candidate.userId=<string>row[2];
		candidate.userName=<string>row[1];
		candidate.ipAddress=<string>row[3];
		candidate.emailAddress=<string>row[4];
		testData.candidate=candidate;
		return testData;
	}

	//Assign Button Event
	assingTest(row) 
	{
		this.checkEditPressed=true;
		let blockDuplicates: boolean = true;

		let testData:TestData=this.setPropertiesToTestData(row,new TestData(),new Candidate());

		//Check pre-assignment of Test Paper
		if (this.assinedIpAddresses.length == 0)
		 {
			this.assignedTestData.push(testData);
			this.assinedIpAddresses.push(testData.candidate.ipAddress);
		}
		else 
		{
			for (let i = 0; i < this.assinedIpAddresses.length; i++) 
			{
				if (this.assinedIpAddresses[i] == testData.candidate.ipAddress) 
				{
					console.log("match found");
					console.log(">>>>>>>>" + this.assinedIpAddresses[i] + "  " + testData.candidate.ipAddress);
					blockDuplicates = false;
				}
			}
			if (blockDuplicates) 
			{
				this.assignedTestData.push(testData);
				this.assinedIpAddresses.push(testData.candidate.ipAddress);
			}
		}
	}


	//*******************************************publishing test papers**************************************** */
	//assignedTestData:string[]=[];
	checkcompletedAssigned: boolean;
	onPublishTestSets() {
		if (this.assignedTestData.length == this.data.length) 
		{
			this.checkcompletedAssigned = true;
		}
		if (!this.checkcompletedAssigned) {
			alert("You have not assigned whole test paper");
		}
		else 
		{
			console.log(this.assignedTestData);
		}
	}


	// **************************************************DISAPPEAR ASSIGN BUTTON****************************
	testPaperAssigned:string;
	checkTestPaperAssignment(row)
	{
		let flag:boolean;
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==<string>row[3])
			{	
				this.testPaperAssigned=this.assignedTestData[i].testPaperSet;	
				flag=true;
			}	
		}
		return flag;
	}

	editPressedOnRow:TestData;
	checkEditPressed:boolean;
	onEditTestAssingment(row)
	{
		this.checkEditPressed=false;
		this.editPressedOnRow=row;
	}
	editAssingmentOfTest(event,row)
	{
		this.checkEditPressed=true;
		this.editPressedOnRow=null;
		let index=this.assignedTestData.indexOf(this.findObjectFromTestData(<string>row[3]));
		let t:TestData=new TestData();
		let c:Candidate=new Candidate();
		t=this.setPropertiesToTestData(row,t,c);
		t.testPaperSet=event.target.value;
		this.assignedTestData.push(t);
		this.assignedTestData.splice(index,1);
	}

	findObjectFromTestData(ipAddress:string):TestData
	{
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==ipAddress)
			{
				return this.assignedTestData[i];
			}
		}
	}

	
	
	finalTestJSON(assignedTestData:TestData[]):TestJSON[]
	{
		let testJSON:TestJSON[]=[];
		for(let i=0;i<assignedTestData.length;i++)
		{
			let t:TestJSON=new TestJSON();
			t.srNo=assignedTestData[i].srNo;
			t.ipAddress=assignedTestData[i].candidate.ipAddress;
			t.userName=assignedTestData[i].candidate.userName;
			t.userId=assignedTestData[i].candidate.userId;		
			t.emailAddress=assignedTestData[i].candidate.emailAddress;
			t.dateOfAssignment=assignedTestData[i].dateOfAssignment;
			testJSON.push(t);
		}
		return testJSON;
	}	
	ngOnInit() {
	}

}

import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { MptDetails } from '../../models/mpt-details';
import { Batch } from '../../models/batch';

@Component({
  selector: 'app-view-test-sets',
  templateUrl: './view-test-sets.component.html',
  styleUrls: ['./view-test-sets.component.css']
})
export class ViewTestSetsComponent implements OnInit {

  constructor(private adminService:AdminService) { }
  paperSets:MptDetails[];
  selectedBatchName:Batch;
  selectedTestType:string;
  selectedModule:string;

  
  batches:Batch[];

  ngOnInit() {
    this.adminService.getBatch("CHENNAI","SIPCOT")
    .subscribe((res)=>{
      this.batches=res;
    });

  }
  onSelectingBatch(batch:Batch)
  {
    
  }
  onModuleSelection()
  {
    this.adminService
    .getUploadedPaperSets(this.selectedBatchName._id,this.selectedTestType.toUpperCase(),this.selectedModule.toUpperCase())
    .subscribe((data)=>{
        this.paperSets=data;
    });   
  }
  onSelectingTestType(testType)
  {
    
  }
  
}
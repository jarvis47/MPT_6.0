import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx/types';
import { TestData } from '../../models/test-data';
import {Candidate} from '../../models/candidate';
import { TestJSON } from '../../models/test-JSON';
import { AdminService } from '../../services/admin.service';
import { Batch } from '../../models/batch';
import { FormGroup, FormControl } from '@angular/forms';
import { MptDetails } from '../../models/mpt-details';
import { distinct } from '../../../../node_modules/rxjs/operators';
import {AssignedMpt} from '../../models/assigned-mpt';

@Component({
	selector: 'app-assign-test-sets',
	templateUrl: './assign-test-sets.component.html',
	styleUrls: ['./assign-test-sets.component.css']
})
export class AssignTestSetsComponent implements OnInit {

	assignMptSetForm:FormGroup;
	batchData:Batch[];
	//finalTestData: string[][] = [];
	selectedBatchId:string;
	selectedModuleNo:string;
	selectedMptSet:string;
	mptSets:MptDetails[];
	candidates:Candidate[];
	testDate:Date;
	//validate
	batchSelected:boolean;
	moduleSelected:boolean;
	testSetSelected:boolean;
	showRow2:boolean;
	testType:string;
	testTypeSelected:boolean;

	
	
	mptDetails:MptDetails[];
	modules:string[];
	assignedMptCandidates:AssignedMpt[]=[];

	constructor(private adminService:AdminService) {
		this.assignMptSetForm=new FormGroup({
			selectedDateOfTest:new FormControl(''),
			selectedTimeOfTest:new FormControl(''),
			selectedBatchId:new FormControl(''),
			selectedTestType:new FormControl(''),
			selectedModule:new FormControl(''),
			selectedMptSet:new FormControl(''),
			editMptSet:new FormControl('')
		});
	}

	ngOnInit() {
		
	}
	distinctMods(mptDetails:MptDetails[]):string[]
	{
		let result:string[]=[];
		for(let i=0;i<mptDetails.length;i++)
		{
			result.push(mptDetails[i].module);
		}
		let filteredArray = result.filter(function(item, pos){
			return result.indexOf(item)== pos; 
		  });
		  return filteredArray;
	}

	onSelectingTestType(testType:string)
	{
		this.testType=testType.toUpperCase();
		this.mptDetails=null;
		this.batchData=null;
		this.modules=null;
		this.adminService.getBatch("CHENNAI","SIPCOT").subscribe((data)=>{
			this.batchData=data;
		});


		let today:Date=new Date();
		let month=today.getMonth();
		let day=today.getDate();
		let year=today.getFullYear();
		let newDate:Date=new Date(month+"/"+day+"/"+year);
		console.log(newDate);

	}

	onSelectingBatch(batch:string)
	{
		this.selectedBatchId=batch;
		console.log("batchID => "+batch);
		this.adminService
		.getModulesFromMptSet(batch)
		.subscribe((res)=>{
			this.mptDetails=res;
			this.modules=this.distinctMods(this.mptDetails);
		});

	}

	selectedModule(module:string)
	{
		this.adminService.getUploadedPaperSets(this.selectedBatchId,this.testType,module.toUpperCase())
		.subscribe((res)=>{
			this.mptSets=res;
		});

	}

	selectedMptSetId:string;
	onSelectingMPT(setId:string)
	{
		this.testSetSelected=true;
		this.selectedMptSetId=setId;
		this.adminService
		.getCandidateBasedOnBatchName(this.selectedBatchId)
		.subscribe((batchData)=>{
			this.candidates=batchData;
		});
	}

	onTestAssign(candidate:Candidate)
	{
		

		let assignedData=new AssignedMpt();
		assignedData.candidateId=candidate._id;
		assignedData.mptSetId=this.selectedMptSetId;
		assignedData.status="assigned";
		this.assignedMptCandidates.push(assignedData);
		console.log(this.assignedMptCandidates);
		this.editButtonPressed=false;
	}
	

	assignButtonClicked(candidate:Candidate):boolean
	{	
		for(let i=0;i<this.assignedMptCandidates.length;i++)
		{
			if(this.assignedMptCandidates[i].candidateId==candidate._id)
			{	
				return true;
			}
		}
		return false;
	}
	getSetName(candidate:Candidate):string
	{
		let setName:string="";
		let setId="";
		for(let i=0;i<this.assignedMptCandidates.length;i++)
		{
			if(this.assignedMptCandidates[i].candidateId==candidate._id)
			{	
				console.log("setted mpt set id");
				setId=this.assignedMptCandidates[i].mptSetId;
			}
		}
		for(let i=0;i<this.mptDetails.length;i++)
		{
			if(this.mptDetails[i]._id==setId)
			{
				console.log("setted mpt set name");
				setName=this.mptDetails[i].testPaperSetName;
			}
		}
		return setName;
	}
	beforeSelectionMod(module)
	{
		this.moduleSelected=true;
		this.mptSets=null;

	}

	editingCandidateMpt:Candidate;
	editButtonPressed:boolean;
	editMptSet(candidate:Candidate,setName:string)
	{	
		this.editingCandidateMpt=candidate;
		this.editButtonPressed=true;
	}

	onAssignUpdate(candidate)
	{

	}
	/*
	
	
	
	selectedModule(event)
	{
		
		
	}

	
	onSelectingMPT()
	{
		this.testSetSelected=true;
		
		this.adminService
		.getCandidateBasedOnBatchName(this.selectedBatchId._id)
		.subscribe((batchData)=>{
			this.candidates=batchData;
		});
	}
	onTestAssign(candidate:Candidate)
	{

	}
	/*
	choosedPaperSet: boolean;
	choosedLabDetails: boolean;
	testAssinedToIndividual: boolean;
	paperSetName: string;
	testAssignedToIndividual: string;


	//*******************************Choose paper set*********************************************

	selectedSet;
	onChoosePaperSet(event: any) {
		this.paperSetName = event.target.value;
		console.log("paper set :" + this.paperSetName);
		this.choosedPaperSet = true;
	}

	//************************************Assign Test to Particular Uses**************************************

	assignedTestData: TestData[] = [];

	assinedIpAddresses: string[] = [];
	
	//Set Properties into the TestData

	setPropertiesToTestData(row:any[],testData:TestData,candidate:Candidate)
	{
		testData.srNo= <string>row[0];
		testData.testPaperSet=this.paperSetName;
		testData.dateOfAssignment=new Date();
		candidate.userId=<string>row[2];
		candidate.userName=<string>row[1];
		candidate.ipAddress=<string>row[3];
		candidate.emailAddress=<string>row[4];
		testData.candidate=candidate;
		return testData;
	}

	//Assign Button Event
	assingTest(row) 
	{
		//this.checkEditPressed=true;
		let blockDuplicates: boolean = true;

		let testData:TestData=this.setPropertiesToTestData(row,new TestData(),new Candidate());

		//Check pre-assignment of Test Paper
		if (this.assinedIpAddresses.length == 0)
		 {
			this.assignedTestData.push(testData);
			this.assinedIpAddresses.push(testData.candidate.ipAddress);
		}
		else 
		{
			for (let i = 0; i < this.assinedIpAddresses.length; i++) 
			{
				if (this.assinedIpAddresses[i] == testData.candidate.ipAddress) 
				{
					console.log("match found");
					console.log(">>>>>>>>" + this.assinedIpAddresses[i] + "  " + testData.candidate.ipAddress);
					blockDuplicates = false;
				}
			}
			if (blockDuplicates) 
			{
				this.assignedTestData.push(testData);
				this.assinedIpAddresses.push(testData.candidate.ipAddress);
			}
		}
	}

/*
	//*******************************************publishing test papers
	//assignedTestData:string[]=[];
	checkcompletedAssigned: boolean;
	onPublishTestSets() {
		if (this.assignedTestData.length == this.data.length) 
		{
			this.checkcompletedAssigned = true;
		}
		if (!this.checkcompletedAssigned) {
			alert("You have not assigned whole test paper");
		}
		else 
		{
			console.log(this.assignedTestData);
		}
	}


	// **************************************************DISAPPEAR ASSIGN BUTTON****************************
	testPaperAssigned:string;
	checkTestPaperAssignment(row)
	{
		let flag:boolean;
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==<string>row[3])
			{	
				this.testPaperAssigned=this.assignedTestData[i].testPaperSet;	
				flag=true;
			}	
		}
		return flag;
	}

	editPressedOnRow:TestData;
	checkEditPressed:boolean;
	onEditTestAssingment(row)
	{
		this.checkEditPressed=false;
		this.editPressedOnRow=row;
	}
	editAssingmentOfTest(event,row)
	{
		this.checkEditPressed=true;
		this.editPressedOnRow=null;
		let index=this.assignedTestData.indexOf(this.findObjectFromTestData(<string>row[3]));
		let t:TestData=new TestData();
		let c:Candidate=new Candidate();
		t=this.setPropertiesToTestData(row,t,c);
		t.testPaperSet=event.target.value;
		this.assignedTestData.push(t);
		this.assignedTestData.splice(index,1);
	}

	findObjectFromTestData(ipAddress:string):TestData
	{
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==ipAddress)
			{
				return this.assignedTestData[i];
			}
		}
	}

	
	
	finalTestJSON(assignedTestData:TestData[]):TestJSON[]
	{
		let testJSON:TestJSON[]=[];
		for(let i=0;i<assignedTestData.length;i++)
		{
			let t:TestJSON=new TestJSON();
			t.srNo=assignedTestData[i].srNo;
			t.ipAddress=assignedTestData[i].candidate.ipAddress;
			t.userName=assignedTestData[i].candidate.userName;
			t.userId=assignedTestData[i].candidate.userId;		
			t.emailAddress=assignedTestData[i].candidate.emailAddress;
			t.dateOfAssignment=assignedTestData[i].dateOfAssignment;
			testJSON.push(t);
		}
		return testJSON;
	}	
	*/

	

}

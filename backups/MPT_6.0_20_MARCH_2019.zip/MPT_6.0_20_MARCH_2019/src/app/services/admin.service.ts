import { Injectable, OnInit } from '@angular/core';
import {MptDetails} from '../models/mpt-details';
import { Batch } from '../models/batch';
import { Http, Response, RequestOptions,Headers } from '@angular/http';
import { map, catchError } from 'rxjs/operators';
import { Candidate } from '../models/candidate';



@Injectable({
  providedIn: 'root'
})
export class AdminService implements OnInit {

  
  UploadAndSaveMptDetailsURL="/api/mpt-set/upload-store";
  uploadAndSaveBatchDetailsURL="/api/batch/upload-store";
  getUploadedSetsURL="/api/getMpts";
  testPaperUploadURL="/api/file-upload";
  getBatcheURL="/api/get-batch";
  findBatchId="/api/checkBatchId";
  getCandidateBasedOnBatchIdURL="/api/getCandidates";
  saveCandidateData="/api/store-candidates"
  findCountOfBatches:string="/api/findBatchCount";
  getModulesOfBatchFromMptSet="/api/get-modules";
  count:number;
  constructor(private http:Http) {
    
  }
  
  ngOnInit(){
   
  }
  
  //-------------------validation of batch ID existence----------------------------------/
  checkBatchId(batchId:string,location:string,subLocation:string)
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});

    //trim and uppercase 
    batchId=batchId.trim().toUpperCase();

    let queryString:string = '?batchId='+batchId;//+"&location="+location+"&subLocation="+subLocation;

    return this.http.get(this.findBatchId+queryString,options)
                    .pipe(map((response : Response) => {
                                  return response.json() as string;   
                                    }));
  }

  //----------------------Upload Files and save batch details  sets----------------------/

  // 1. upload and save batch details
  batchId:string;
  uploadAndSaveBatchDetails(batchDetails:Batch,selectedFile:File,candidateData:Candidate[])
  {

    // //create batch id
    // this.batchId=batchDetails.location+"_"+batchDetails.subLocation+"_"+(this.count+Math.floor(Math.random()*1000));
    // batchDetails._id=this.batchId;

    //trim and uppercase batchModel
    this.batchId=batchDetails._id.trim().toUpperCase();
    batchDetails.batchName=batchDetails.batchName.trim().toUpperCase();
    batchDetails._id=this.batchId;
    batchDetails.location = batchDetails.location.trim().toUpperCase();
    batchDetails.subLocation = batchDetails.subLocation.trim().toUpperCase();
    batchDetails.lotName = batchDetails.lotName.trim().toUpperCase();

    //batchId in candidate table and trim n uppercase n lowercase
    candidateData=this.assignBatchID(candidateData);
    

    const uploadBatchData = new FormData();
    uploadBatchData.append('myFile',selectedFile, selectedFile.name);
    uploadBatchData.append('candidateData',JSON.stringify(candidateData));
    uploadBatchData.append('batchDetailsModel',JSON.stringify(batchDetails));
     return this.http.post(this.uploadAndSaveBatchDetailsURL, uploadBatchData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as Batch;   
      }));
    
  }


//----------------------Upload Files and save test details----------------------/
  uploadAndSaveMpt(mptDetails:MptDetails,selectedFile:File)
  {
    //trim and uppercase
    mptDetails.module=mptDetails.module.trim().toUpperCase();
    mptDetails.testPaperSetName = mptDetails.testPaperSetName.trim().toUpperCase();
    mptDetails.testPaperType = mptDetails.testPaperType.trim().toUpperCase();
    mptDetails.location = mptDetails.location.trim().toUpperCase();

    const uploadMptData = new FormData();
    uploadMptData.append('myFile',selectedFile, selectedFile.name);
    uploadMptData.append('mptDetailsModel',JSON.stringify(mptDetails));
     return this.http.post(this.UploadAndSaveMptDetailsURL, uploadMptData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as MptDetails;   
      }));
    
  }
  

  
/**********************************GEt data from db*********************************** */

    
//----------------------get uploaded mpts----------------------/
  getUploadedPaperSets(batchId:string,testType:string,module:string)
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
    let queryString:string='?batchId='+batchId+"&testType="+testType+"&module="+module;
    return this.http.get(this.getUploadedSetsURL+queryString,options)
    .pipe(map((response : Response) => {
        return response.json() as MptDetails[];   
    }));
  }
  

  //----------------------get added batches ----------------------/
  getBatch(location:string,subLocation:string)
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
    let queryString="?location="+location+"&subLocation="+subLocation;
    return this.http.get(this.getBatcheURL+queryString,options)
    .pipe(map((response : Response) => {
        return response.json() as Batch[];   
    }));
  }

  //----------------------get candidates----------------------/

    //Based on batch name : //have to modify
    getCandidateBasedOnBatchName(batchId:string)
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});
      console.log(batchId);
      let queryString:string="?batchId="+batchId;

      return this.http.get(this.getCandidateBasedOnBatchIdURL+queryString,options)
      .pipe(map((response : Response) => {
          return response.json() as Candidate[];    
      }));
      
    }

    //----------------get modules---------------------------

    
    getModulesFromMptSet(batchId:string)
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});
      let queryString="?batchId="+batchId;

      return this.http.get(this.getModulesOfBatchFromMptSet+queryString,options)
      .pipe(map((response : Response) => {
          return response.json() as MptDetails[];    
      }));
    }


  //--------------------------------------Find count of Batches----------------
    findCountOfBatchCollection()
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});

      return this.http.get(this.findCountOfBatches,options)
      .pipe(map((response : Response) => {
          return response.json() as number;    //have to modify
      }));
    }

    assignBatchID(candidate:Candidate[]):Candidate[]
    {
        for(let i=0;i<candidate.length;i++)
        {
          candidate[i].batchId=this.batchId;
          candidate[i].userId=candidate[i].userId.trim().toLowerCase();
          candidate[i].ipAddress=candidate[i].ipAddress.trim();
          if(candidate[i].password!=undefined || candidate[i].password!=null)
            candidate[i].password=candidate[i].password.trim();
        }
        return candidate;
    }



  private handleError (error: any): Promise<any> 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console
    return Promise.reject(errMsg);
  }
  



}

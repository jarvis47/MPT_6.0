import { Time } from "@angular/common";

export class MptDetails 
{
    _id?:string;
    testPaperSetFileURL:string;
    testPaperSetName:string;
    location:string;
    subLocation:string;
    module:string;
    batchId:string;
    dateOfUpload:Date;
    timeOfUpload:Time;
    testPaperType:string;
    setNumber:number;
    assignmentId:string; 
}
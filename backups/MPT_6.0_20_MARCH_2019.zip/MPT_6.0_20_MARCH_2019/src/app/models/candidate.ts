
export class Candidate 
{
    _id?:string;
    userName:string;
    userId:string;
    emailAddress:string;
    ipAddress:string;
    password:string=null; // We will see how to use it
    batchId:string=null; //object id of batch
}

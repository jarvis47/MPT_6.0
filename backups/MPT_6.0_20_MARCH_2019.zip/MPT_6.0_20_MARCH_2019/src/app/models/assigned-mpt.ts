export class AssignedMpt
{
    _id?:string;
    mptSetId:string;
    candidateId:string;
    dateOfTest:Date;
    timeOfTest:Date;
    status:string;
}
export class Candidate 
{
    userName:string;
    userId:string;
    emailAddress:string;
    ipAddress:string;
    password:string; // We will see how to use it
}

export class FileUploadedModel {
    //Change name of this class
    fileUrl:string;
    dateOfUpload:Date
}

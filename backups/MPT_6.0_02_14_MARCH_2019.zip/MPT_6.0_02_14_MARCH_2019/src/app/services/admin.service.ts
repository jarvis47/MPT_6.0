import { Injectable } from '@angular/core';
import {UploadTestDetails} from '../models/uploadTestDetails';
import {FileUploadedModel} from '../models/file-uploaded-model';
//import { Http } from '@angular/http';
import { Batch } from '../models/batch';
import { Http, Response, RequestOptions,Headers } from '@angular/http';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  saveUploadDetailsURL="/api/testPaperSets/store";
  saveUploadBatchDetailsURL="/api/batch/store";
  getUploadedSetsURL="api/getAllMpts";
  testPaperUploadURL="/api/file-upload";

  constructor(private http:Http) {}

  uploadFile(selectedFile:File,testPaperSetName:string,fileIdentity:string): Promise<FileUploadedModel>
  {
    const uploadData = new FormData();
    uploadData.append('myFile',selectedFile, selectedFile.name);
    uploadData.append('fileName',testPaperSetName);
    uploadData.append('fileIdentity',fileIdentity);
     return this.http.post(this.testPaperUploadURL, uploadData)
    .toPromise()
    .then(response => {response.json() as FileUploadedModel})
    .catch(this.handleError);
    
  }
     storeTestUploadedBatchDetails(newBatch: Batch): Promise<Batch> {
    return this.http.post(this.saveUploadBatchDetailsURL, newBatch)
               .toPromise()
               .then(response => response.json() as Batch)
               .catch(this.handleError);
  }
   storeTestUploadedSet(newTestPaperSet: UploadTestDetails): Promise<UploadTestDetails> {
    return this.http.post(this.saveUploadDetailsURL, newTestPaperSet)
               .toPromise()
               .then(response => response.json() as UploadTestDetails)
               .catch(this.handleError);
  }
  


  stringText:string;
  
   // get("/api/testPaperSets")
   /*getUploadedPaperSets(): Promise<string> 
   {
    return this.http.get(this.getUploadedSetsURL)
               .toPromise()
               .then(response => response.text() as string)
               .catch(this.handleError);
  }*/
  getUploadedPaperSets()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getUploadedSetsURL,options)
    .pipe(map((response : Response) => {
        return response.json();   
    }));
  }

  
  private handleError (error: any): Promise<any> 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console
    return Promise.reject(errMsg);
  }


}

import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { UploadTestDetails } from '../../models/uploadTestDetails';

@Component({
  selector: 'app-view-test-sets',
  templateUrl: './view-test-sets.component.html',
  styleUrls: ['./view-test-sets.component.css']
})
export class ViewTestSetsComponent implements OnInit {

  constructor(private adminService:AdminService) { }
  paperSets: UploadTestDetails[];

  ngOnInit() {
    this.adminService
    .getUploadedPaperSets()
    .subscribe((data)=>{
        console.log(data);
    });
    /*
    .then((paperSets:string)=>{
      console.log(typeof paperSets);
    });*/
  }
  
  showContacts()
  {
    
  }
}
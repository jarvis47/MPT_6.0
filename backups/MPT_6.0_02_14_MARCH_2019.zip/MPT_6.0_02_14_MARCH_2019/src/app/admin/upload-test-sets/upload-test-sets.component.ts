import { Component, OnInit } from '@angular/core';
import {AdminService} from '../../services/admin.service';
import { Http } from '@angular/http'
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {UploadTestDetails} from '../../models/uploadTestDetails';
import {FileUploadedModel} from '../../models/file-uploaded-model';
const url = "http://localhost:8080/fileupload";

@Component({
  selector: 'app-upload-test-sets',
  templateUrl: './upload-test-sets.component.html',
  styleUrls: ['./upload-test-sets.component.css']
})
export class UploadTestSetsComponent implements OnInit 
{
  uploadTestPaperSetForm:FormGroup;
  constructor(private adminService:AdminService,private http:Http) { 
    this.uploadTestPaperSetForm=new FormGroup({
      selectedTestPaperSetFile:new FormControl(''),
      selectedLocation:new FormControl(''),
      selectedSubLocation:new FormControl(''),
      selectedBatchName:new FormControl(''),
      selectedModule:new FormControl(''),
      selectedSetNumber:new FormControl(''),
      testType:new FormControl('')
  });
  }
  location:string[]=['Chennai'];
  
  subLocation:string[]=['SIPCOT','MIPL','PCT'];
  
  batchName:string[]=['JEE_FULLSTACK_FS','JEE_ABRIDGE_NON_FS','JAVASCRIPT_FULLSTACK_FS'];
  
  module:string[]=['Module 1','Module 2','Module 3','Module 4','Module 5'];

  selectedFile;
  onFileSelect(event)
  {
   this.selectedFile = event.target.files[0];
  
  }
  //Validators
  emptyFile:boolean;
  emptyLocation:boolean;
  emptySubLocation:boolean;
  emptyBatchName:boolean;
  emptyModuleName:boolean;

 onSubmit()
 {
    //create an instance of model
  let uploadTestDetailsModel =new UploadTestDetails();
  //let fileUploadedModel=new FileUploadedModel();
  
  //set form data into that

   let selectedLocation=this.uploadTestPaperSetForm.controls['selectedLocation'].value;
   uploadTestDetailsModel.location=selectedLocation;
   
   let selectedSubLocation=this.uploadTestPaperSetForm.controls['selectedSubLocation'].value;
   uploadTestDetailsModel.subLocation=selectedSubLocation;
   
   let selectedBatchName=this.uploadTestPaperSetForm.controls['selectedBatchName'].value;
   uploadTestDetailsModel.batchName=selectedBatchName;
   
   let selectedModule=this.uploadTestPaperSetForm.controls['selectedModule'].value; 
   uploadTestDetailsModel.module=selectedModule;
   
   let testType=this.uploadTestPaperSetForm.controls['testType'].value; 
   uploadTestDetailsModel.testPaperType=testType;

   //Todays Date 
   uploadTestDetailsModel.dateOfUpload=new Date();

   let setNumber=this.uploadTestPaperSetForm.controls['selectedSetNumber'].value; 
   uploadTestDetailsModel.setNumber=setNumber;

   //set test paper name
   let testPaperSetName=selectedBatchName+"_"+testType+"_set_"+setNumber+"_"+selectedModule;
   uploadTestDetailsModel.testPaperSetName=testPaperSetName;

  if(this.selectedFile==null)
  {
    alert("Please select File !!");
  }
  else
  {
    /***********************************************Upload File************************************ */

    this.adminService.uploadFile(this.selectedFile,testPaperSetName,"testPaper")
    .then((modelResponse:FileUploadedModel)=>
    {
      console.log(modelResponse)
    });



   /***************************************save test details in db******************************* */
  
   //Saving details here
  this.adminService.storeTestUploadedSet(uploadTestDetailsModel).then((modelResponse:UploadTestDetails)=>
  {  
    console.log("Response from database : ID now -"+modelResponse._id + "\nDate of upload  : "+modelResponse.dateOfUpload);
    console.log("test paper name : "+modelResponse.testPaperSetName);
    });

  
 }
}

  ngOnInit() {
  }

}

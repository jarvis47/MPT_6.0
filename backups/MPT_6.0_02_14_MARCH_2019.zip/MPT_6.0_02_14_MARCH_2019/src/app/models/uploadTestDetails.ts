export class UploadTestDetails 
{
    _id?:string;
    testPaperSetFileURL:string;
    testPaperSetName:string;
    location:string;
    subLocation:string;
    module:string;
    batchName:string;
    dateOfUpload:Date;
    testPaperType:string;
    setNumber:number;
    assignmentId:string;    
}
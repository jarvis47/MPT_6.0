import { Injectable } from '@angular/core';
import {UploadTestDetails} from '../models/uploadTestDetails';
import * as XLSX from 'xlsx';
//import { Http } from '@angular/http';
import { Batch } from '../models/batch';
import { Http, Response, RequestOptions,Headers } from '@angular/http';
import { map, catchError } from 'rxjs/operators';
import { Candidate } from '../models/candidate';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  UploadAndSaveMptDetailsURL="/api/mpt-set/upload-store";
  uploadAndSaveBatchDetailsURL="/api/batch/upload-store";
  getUploadedSetsURL="/api/getAllMpts";
  testPaperUploadURL="/api/file-upload";
  getBatcheURL="/api/get-batch";
  findBatchName="/api/checkBachName";
  getCandidateBasedOnBatchNameURL="/api/getCandidates";
  
  constructor(private http:Http) {}
  
  batchFounded={status:0};
  
  //-------------------Check batch name added or not----------------------------------/
  checkBatchName(batchName:string)
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    
    let options = new RequestOptions({ headers: myHeaders});
    let queryString:string='?batchName='+batchName;
    return this.http.get(this.findBatchName+queryString,options)
                    .pipe(map((response : Response) => {
                                  return response.json() as string;   
                                    }));
  }

  //----------------------Upload Files and save batch details  sets----------------------/
  uploadAndSaveBatchDetails(batchDetails:Batch,selectedFile:File,batchName:string)
  {
    
    const uploadBatchData = new FormData();
    uploadBatchData.append('myFile',selectedFile, selectedFile.name);
    uploadBatchData.append('fileName',batchName);
    uploadBatchData.append('batchDetailsModel',JSON.stringify(batchDetails));
     return this.http.post(this.uploadAndSaveBatchDetailsURL, uploadBatchData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as Batch;   
      }));
    
  }

//----------------------Upload Files and save test details----------------------/
  uploadAndSaveMpt(uploadTestDetails:UploadTestDetails,selectedFile:File,testPaperSetName:string)
  {
    
    const uploadMptData = new FormData();
    uploadMptData.append('myFile',selectedFile, selectedFile.name);
    uploadMptData.append('fileName',testPaperSetName);
    uploadMptData.append('uploadTestDetailsModel',JSON.stringify(uploadTestDetails));
     return this.http.post(this.UploadAndSaveMptDetailsURL, uploadMptData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as UploadTestDetails;   
      }));
    
  }
  

  
/**********************************GEt data from db*********************************** */

    
//----------------------get uploaded mpts----------------------/
  getUploadedPaperSets()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getUploadedSetsURL,options)
    .pipe(map((response : Response) => {
        return response.json() as UploadTestDetails[];   
    }));
  }
  

  //----------------------get added batches ----------------------/
  getBatch()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getBatcheURL,options)
    .pipe(map((response : Response) => {
        return response.json() as Batch[];   
    }));
  }

  //----------------------get candidates----------------------/

    //Based on batch name : //have to modify
    getCandidateBasedOnBatchName(batchName:string)
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});
      let queryString:string="?batchName="+batchName;

      return this.http.get(this.getCandidateBasedOnBatchNameURL+queryString,options)
      .pipe(map((response : Response) => {
          return response.json() as Batch[];    //have to modify
      }));
      
    }

  
  private handleError (error: any): Promise<any> 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console
    return Promise.reject(errMsg);
  }
  



}

import {Candidate} from './candidate';
export class Batch 
{
    _id:string;
    batchName:string;
    location:string;
    subLocation:string;
    joiningDate:Date;
    endDate:Date;
    lotName:string;
    candidateDetails:Candidate[];
    batchFileURL:string;
    dateOfUpload:string;
    timeOfUpload:string;
}

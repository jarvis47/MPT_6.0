import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-assigned-test-sets',
  templateUrl: './view-assigned-test-sets.component.html',
  styleUrls: ['./view-assigned-test-sets.component.css']
})
export class ViewAssignedTestSetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }
 
}

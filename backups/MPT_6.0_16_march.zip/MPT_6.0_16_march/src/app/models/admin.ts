export class admin 
{
  _id?: string;
  userid:string;
  password:string;
  name: string;
  email: string;
  role:string;
  superAdmin:string;
}
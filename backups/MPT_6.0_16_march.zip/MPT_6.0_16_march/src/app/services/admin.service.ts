import { Injectable } from '@angular/core';
import {UploadTestDetails} from '../models/uploadTestDetails';
import {FileUploadedModel} from '../models/file-uploaded-model';
//import { Http } from '@angular/http';
import { Batch } from '../models/batch';
import { Http, Response, RequestOptions,Headers } from '@angular/http';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  UploadAndSaveMptDetailsURL="/api/mpt-set/upload-store";
  uploadAndSaveBatchDetailsURL="/api/batch/upload-store";
  getUploadedSetsURL="/api/getAllMpts";
  testPaperUploadURL="/api/file-upload";
  getBatcheURL="/api/get-batch";

  constructor(private http:Http) {}

  //----------------------Upload Files and save batch details  sets----------------------/
  uploadAndSaveBatchDetails(batchDetails:Batch,selectedFile:File,batchName:string)
  {
    
    const uploadBatchData = new FormData();
    uploadBatchData.append('myFile',selectedFile, selectedFile.name);
    uploadBatchData.append('fileName',batchName);
    uploadBatchData.append('batchDetailsModel',JSON.stringify(batchDetails));
     return this.http.post(this.uploadAndSaveBatchDetailsURL, uploadBatchData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as Batch;   
      }));
    
  }

//----------------------Upload Files and save test details----------------------/
  uploadAndSaveMpt(uploadTestDetails:UploadTestDetails,selectedFile:File,testPaperSetName:string)
  {
    
    const uploadMptData = new FormData();
    uploadMptData.append('myFile',selectedFile, selectedFile.name);
    uploadMptData.append('fileName',testPaperSetName);
    uploadMptData.append('uploadTestDetailsModel',JSON.stringify(uploadTestDetails));
     return this.http.post(this.UploadAndSaveMptDetailsURL, uploadMptData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as UploadTestDetails;   
      }));
    
  }
  

  
/**********************************GEt data from db*********************************** */

    
//----------------------get uploaded mpts----------------------/
  getUploadedPaperSets()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getUploadedSetsURL,options)
    .pipe(map((response : Response) => {
        return response.json() as UploadTestDetails[];   
    }));
  }
  
  //----------------------get added batches ----------------------/
  getBatch()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getBatcheURL,options)
    .pipe(map((response : Response) => {
        return response.json() as Batch[];   
    }));
  }



  private handleError (error: any): Promise<any> 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console
    return Promise.reject(errMsg);
  }


}

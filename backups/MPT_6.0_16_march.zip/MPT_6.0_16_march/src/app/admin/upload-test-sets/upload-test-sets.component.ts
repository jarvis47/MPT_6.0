import { Component, OnInit } from '@angular/core';
import {AdminService} from '../../services/admin.service';
import { Http } from '@angular/http'
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {UploadTestDetails} from '../../models/uploadTestDetails';
import {FileUploadedModel} from '../../models/file-uploaded-model';
import { Batch } from '../../models/batch';

@Component({
  selector: 'app-upload-test-sets',
  templateUrl: './upload-test-sets.component.html',
  styleUrls: ['./upload-test-sets.component.css']
})
export class UploadTestSetsComponent implements OnInit 
{
  uploadTestPaperSetForm:FormGroup;
  batchData:Batch[]=[];
  ngOnInit() {
     //GET BATCH NAME AND ID FROM THE DATABASE
     this.adminService
     .getBatch()
     .subscribe((data)=>{
       this.batchData=data;
     });
  }
  constructor(private adminService:AdminService,private http:Http) { 
    //SET FORM CONTROLS
    this.uploadTestPaperSetForm=new FormGroup({
      selectedTestPaperSetFile:new FormControl(''),
      selectedBatch:new FormControl(''),
      selectedModule:new FormControl(''),
      selectedSetNumber:new FormControl(''),
      testType:new FormControl('')
  });
     
  }
  location:string[]=['Chennai'];
  
  subLocation:string[]=['SIPCOT','MIPL','PCT'];
  
  module:string[]=['Module 1','Module 2','Module 3','Module 4','Module 5'];

  selectedFile;
  onFileSelect(event)
  {
   this.selectedFile = event.target.files[0];
  
  }

  fileUploaded:FileUploadedModel;
  testSaved:UploadTestDetails;

  //on Submitting Form 
  onSubmit()
  {
    //create an instance of model
    let uploadTestDetailsModel =new UploadTestDetails();
    
    //set form data into that
    let selectedBatch=this.uploadTestPaperSetForm.controls['selectedBatch'].value;
    
    //batch name
    uploadTestDetailsModel.batchName=selectedBatch.batchName;

    //batch location
    uploadTestDetailsModel.location=selectedBatch.location;

    //batch sublocation
    uploadTestDetailsModel.subLocation=selectedBatch.subLocation;
    
    let selectedModule=this.uploadTestPaperSetForm.controls['selectedModule'].value; 
    uploadTestDetailsModel.module=selectedModule;
    
    let testType=this.uploadTestPaperSetForm.controls['testType'].value; 
    uploadTestDetailsModel.testPaperType=testType;

    //set number
    let setNumber=this.uploadTestPaperSetForm.controls['selectedSetNumber'].value; 
    uploadTestDetailsModel.setNumber=setNumber;

    //set test paper name
    let testPaperSetName=selectedBatch.batchName+"_set_"+setNumber+"_"+selectedModule+"_"+testType;

    uploadTestDetailsModel.testPaperSetName=testPaperSetName;

    if(this.selectedFile==null)
    {
      alert("Please select File !!");
    }
    else
    {
      
      //Upload File and save details------------------------------------------------------------------
      this.adminService.uploadAndSaveMpt(uploadTestDetailsModel,this.selectedFile,testPaperSetName)
      .subscribe((data)=>{
          this.testSaved=data;
        });
      console.log(this.testSaved);
    }
  }
}
 



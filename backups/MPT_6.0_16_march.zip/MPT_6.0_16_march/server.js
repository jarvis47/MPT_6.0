var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
var formidable = require('formidable');
var fs = require('fs');
var ObjectID = mongodb.ObjectID;

var UPLOADED_TEST_SETS_COLLECTION = "uploaded_mpts";
var BATCH_MASTER = "batch_details"

var app = express();
app.use(bodyParser.json());

// Create link to Angular build directory
var distDir = __dirname + "/dist";
app.use(express.static(distDir));

// Create a database variable outside of the database connection callback to reuse the connection pool in your app.
var db;

// Connect to the database before starting the application server.
mongodb.MongoClient.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/mpt", function (err, client) {
  if (err) {
    console.log(err);
    process.exit(1);
  }

  // Save database object from the callback for reuse.
  db = client.db();
  console.log("Database connection ready");

  // Initialize the app.
  var server = app.listen(process.env.PORT || 8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);

  });
});

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
  console.log("ERROR: " + reason);
  res.status(code || 500).json({ "error": message });
}

// MPT API ROUTES BELOW




//Uploading and saving batch file and data-------------------------------------------------------------------

app.post("/api/batch/upload-store", function (req, res) 
{
  console.log("batch upload function called");
  //Formdata incoming
  var form = new formidable.IncomingForm();

  form.parse(req, function (err, fields, files) 
  {
    var oldpath = files.myFile.path;
    
    //fecthing sent object
    var object=fields.batchDetailsModel;
    
    //parsing object from string to real object
    var batchDetailsModel=JSON.parse(object);

    //new path of file where file would be save
    var newpath = 'C:/Users/rsoudey/Desktop/MPT/MPT_6.0/src/app/uploadedBatchDetails/' + fields.fileName + '.xlsx';

    //upload file at the newpath
    fs.rename(oldpath, newpath, function (err) 
    {
      if (err) throw err;

      //set some details to batch model
      batchDetailsModel.batchFileURL = newpath;
      batchDetailsModel.dateOfUpload=new Date();

      //Store batch model in database 
      db.collection(BATCH_MASTER).insertOne(batchDetailsModel, function (err, doc) 
      {
        if (err) {
          handleError(res, err.message, "Failed to store new test set");
        }
        else {
          console.log("batch model data saved");
          res.status(201).json(doc.ops[0]);
        }
      });
    });
  });
});

// Upload and save mpt test details ---------------------------------------------------------------------

  app.post("/api/mpt-set/upload-store", function (req, res) 
  {
    console.log("test upload function called");
  
    //FormData
    var form = new formidable.IncomingForm();

    //parsing formData object
    form.parse(req, function (err, fields, files) 
    {
      var oldpath = files.myFile.path;

      //object sent via FormData
      var object=fields.uploadTestDetailsModel;
      
      //parsing in JSON format through string
      var uploadTestDetailsModel=JSON.parse(object);

      //new path where our file gonna store
      var newpath = 'C:/Users/rsoudey/Desktop/MPT/MPT_6.0/src/app/uploadedTests/' + fields.fileName + '.docx';
      fs.rename(oldpath, newpath, function (err) 
      {
        if (err) throw err;

        //setting some properties before persisting object in db
        uploadTestDetailsModel.testPaperSetFileURL = newpath;
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        if (dd < 10) {
          dd = '0' + dd;
        } 
        if (mm < 10) {
          mm = '0' + mm;
        } 
        var today = dd + '/' + mm + '/' + yyyy;
        uploadTestDetailsModel.dateOfUpload=today;

        //Time 
        var time=new Date();
        var currentTime=time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();
        uploadTestDetailsModel.timeOfUpload=currentTime;

        //Store uploadTestDetailsModel in database 
        db.collection(UPLOADED_TEST_SETS_COLLECTION).insertOne(uploadTestDetailsModel, function (err, doc) 
        {
          if (err) {
            handleError(res, err.message, "Failed to store new test set");
          }
          else {
            console.log("data saved");
            res.status(201).json(doc.ops[0]);
          }
        });
      });
    });
  });


/*************************************Get data from database ********************************************** */


//-----------------------GEt all mpts----------------------
app.get("/api/getAllMpts/", function (req, res) {
  db.collection(UPLOADED_TEST_SETS_COLLECTION).find({}).sort({"_id":-1}).toArray(function (err, docs) {
    console.log("get data called");
    if (err) {
      handleError(res, err.message, "Failed to get test sets.");
    }
    else {
      res.json(docs);
    }
  });
});

//-----------------------get all batches----------------------
app.get("/api/get-batch",function(req,res){
  db.collection(BATCH_MASTER).find({}).toArray(function(err,docs)
{
  console.log("fetching batches");
  if(err)
  {
    handleError(res, err.message, "Failed to get batches");
  }
  else
  {
    res.json(docs);
  }
})
});

app.get("*", function (req, res) {
  console.log("* called");
  res.sendFile(distDir + "/index.html");
});


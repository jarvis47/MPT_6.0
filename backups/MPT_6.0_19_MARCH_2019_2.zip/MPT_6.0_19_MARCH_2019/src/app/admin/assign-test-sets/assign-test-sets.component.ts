import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { TestData } from '../../models/test-data';
import {Candidate} from '../../models/candidate';
import { TestJSON } from '../../models/test-JSON';
import { AdminService } from '../../services/admin.service';
import { Batch } from '../../models/batch';
import { FormGroup, FormControl } from '../../../../node_modules/@angular/forms';
import { UploadTestDetails } from '../../models/uploadTestDetails';

@Component({
	selector: 'app-assign-test-sets',
	templateUrl: './assign-test-sets.component.html',
	styleUrls: ['./assign-test-sets.component.css']
})
export class AssignTestSetsComponent implements OnInit {

	//assignMptSetForm:FormGroup;
	batchData:Batch[];
	//finalTestData: string[][] = [];
	selectedBatchId:Batch;
	selectedModuleNo:string;
	selectedMptSet:string;
	mptSets:UploadTestDetails[];
	candidates:Candidate[];
	//validate
	batchSelected:boolean;
	moduleSelected:boolean;
	testSetSelected:boolean;


	constructor(private adminService:AdminService) {}

	ngOnInit() {
		this.adminService.getBatch().subscribe((data)=>{
			this.batchData=data;
		});

		this.adminService.getUploadedPaperSets()
		.subscribe((res)=>{
			this.mptSets=res;
		});
	}
	onSelectingBatch(event)
	{
		this.batchSelected=true;
		this.adminService
		.getCandidateBasedOnBatchName(this.selectedBatchId._id)
		.subscribe((batchData)=>{
			this.candidates=batchData;
		});
	}
	selectedModule(event)
	{
		this.moduleSelected=true;
	}

	onSelectingMPT()
	{
		this.testSetSelected=true;
	}
	/*
	choosedPaperSet: boolean;
	choosedLabDetails: boolean;
	testAssinedToIndividual: boolean;
	paperSetName: string;
	testAssignedToIndividual: string;


	//*******************************Choose paper set*********************************************

	selectedSet;
	onChoosePaperSet(event: any) {
		this.paperSetName = event.target.value;
		console.log("paper set :" + this.paperSetName);
		this.choosedPaperSet = true;
	}

	//************************************Assign Test to Particular Uses**************************************

	assignedTestData: TestData[] = [];

	assinedIpAddresses: string[] = [];
	
	//Set Properties into the TestData

	setPropertiesToTestData(row:any[],testData:TestData,candidate:Candidate)
	{
		testData.srNo= <string>row[0];
		testData.testPaperSet=this.paperSetName;
		testData.dateOfAssignment=new Date();
		candidate.userId=<string>row[2];
		candidate.userName=<string>row[1];
		candidate.ipAddress=<string>row[3];
		candidate.emailAddress=<string>row[4];
		testData.candidate=candidate;
		return testData;
	}

	//Assign Button Event
	assingTest(row) 
	{
		//this.checkEditPressed=true;
		let blockDuplicates: boolean = true;

		let testData:TestData=this.setPropertiesToTestData(row,new TestData(),new Candidate());

		//Check pre-assignment of Test Paper
		if (this.assinedIpAddresses.length == 0)
		 {
			this.assignedTestData.push(testData);
			this.assinedIpAddresses.push(testData.candidate.ipAddress);
		}
		else 
		{
			for (let i = 0; i < this.assinedIpAddresses.length; i++) 
			{
				if (this.assinedIpAddresses[i] == testData.candidate.ipAddress) 
				{
					console.log("match found");
					console.log(">>>>>>>>" + this.assinedIpAddresses[i] + "  " + testData.candidate.ipAddress);
					blockDuplicates = false;
				}
			}
			if (blockDuplicates) 
			{
				this.assignedTestData.push(testData);
				this.assinedIpAddresses.push(testData.candidate.ipAddress);
			}
		}
	}

/*
	//*******************************************publishing test papers
	//assignedTestData:string[]=[];
	checkcompletedAssigned: boolean;
	onPublishTestSets() {
		if (this.assignedTestData.length == this.data.length) 
		{
			this.checkcompletedAssigned = true;
		}
		if (!this.checkcompletedAssigned) {
			alert("You have not assigned whole test paper");
		}
		else 
		{
			console.log(this.assignedTestData);
		}
	}


	// **************************************************DISAPPEAR ASSIGN BUTTON****************************
	testPaperAssigned:string;
	checkTestPaperAssignment(row)
	{
		let flag:boolean;
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==<string>row[3])
			{	
				this.testPaperAssigned=this.assignedTestData[i].testPaperSet;	
				flag=true;
			}	
		}
		return flag;
	}

	editPressedOnRow:TestData;
	checkEditPressed:boolean;
	onEditTestAssingment(row)
	{
		this.checkEditPressed=false;
		this.editPressedOnRow=row;
	}
	editAssingmentOfTest(event,row)
	{
		this.checkEditPressed=true;
		this.editPressedOnRow=null;
		let index=this.assignedTestData.indexOf(this.findObjectFromTestData(<string>row[3]));
		let t:TestData=new TestData();
		let c:Candidate=new Candidate();
		t=this.setPropertiesToTestData(row,t,c);
		t.testPaperSet=event.target.value;
		this.assignedTestData.push(t);
		this.assignedTestData.splice(index,1);
	}

	findObjectFromTestData(ipAddress:string):TestData
	{
		for(let i=0;i<this.assignedTestData.length;i++)
		{
			if(this.assignedTestData[i].candidate.ipAddress==ipAddress)
			{
				return this.assignedTestData[i];
			}
		}
	}

	
	
	finalTestJSON(assignedTestData:TestData[]):TestJSON[]
	{
		let testJSON:TestJSON[]=[];
		for(let i=0;i<assignedTestData.length;i++)
		{
			let t:TestJSON=new TestJSON();
			t.srNo=assignedTestData[i].srNo;
			t.ipAddress=assignedTestData[i].candidate.ipAddress;
			t.userName=assignedTestData[i].candidate.userName;
			t.userId=assignedTestData[i].candidate.userId;		
			t.emailAddress=assignedTestData[i].candidate.emailAddress;
			t.dateOfAssignment=assignedTestData[i].dateOfAssignment;
			testJSON.push(t);
		}
		return testJSON;
	}	
	*/

	

}

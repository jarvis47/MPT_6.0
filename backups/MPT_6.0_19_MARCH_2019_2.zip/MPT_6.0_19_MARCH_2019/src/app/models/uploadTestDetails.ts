import { Time } from "../../../node_modules/@angular/common";

export class UploadTestDetails 
{
    _id?:string;
    testPaperSetFileURL:string;
    testPaperSetName:string;
    location:string;
    subLocation:string;
    module:string;
    batchName:string;
    dateOfUpload:Date;
    timeOfUpload:Time;
    testPaperType:string;
    setNumber:number;
    assignmentId:string; 

}
import { Candidate } from "./candidate";

export class TestData {
    
     srNo:string;
     testPaperSet:string;
     testURL:string;
     dateOfAssignment:Date;
     candidate:Candidate;

    
}

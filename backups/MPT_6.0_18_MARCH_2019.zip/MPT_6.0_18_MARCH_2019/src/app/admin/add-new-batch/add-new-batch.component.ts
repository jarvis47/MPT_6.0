import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '../../../../node_modules/@angular/forms';
import { Candidate } from '../../models/candidate';
import { Batch } from '../../models/batch';

import * as XLSX from 'xlsx';
import { AdminService } from '../../services/admin.service';
import { FileUploadedModel } from '../../models/file-uploaded-model';

type AOA = any[][];

@Component({
  selector: 'app-add-new-batch',
  templateUrl: './add-new-batch.component.html',
  styleUrls: ['./add-new-batch.component.css']
})
export class AddNewBatchComponent implements OnInit {

  fileUploaded:FileUploadedModel;
  batchSaved:Batch;
  addNewBatchForm:FormGroup;
  data: Candidate[];
	wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
	fileName: string = 'SheetJS.xlsx';
  selectedFile:File;

  constructor(private adminService:AdminService, ) 
  {
    console.log("const called");
    this.addNewBatchForm=new FormGroup({
      selectedLocation:new FormControl(""),
      selectedSubLocation:new FormControl(""),
      batchName:new FormControl(""),
      lotName:new FormControl(""),
      onBoardingDate:new FormControl(""),
      endDate:new FormControl(""),
      selectedStudentFile:new FormControl("")
    })
   }

   onFileSelect(evt)
   {
     this.selectedFile=evt.target.files[0];
     this.data=this.adminService.readExcelFile(evt);
   }

  onSubmit()
  {
    if(this.founded="0")
    {
      alert("Batch with the same name already Exists")
    }
    else if(this.founded=="1")
    {
      let batchDetails = new Batch();
      batchDetails.location=this.addNewBatchForm.controls['selectedLocation'].value;
      batchDetails.subLocation=this.addNewBatchForm.controls['selectedSubLocation'].value;
      batchDetails.batchName=this.addNewBatchForm.controls['batchName'].value;
      batchDetails.lotName=this.addNewBatchForm.controls['lotName'].value;
      batchDetails.joiningDate=this.addNewBatchForm.controls['onBoardingDate'].value;
      batchDetails.endDate=this.addNewBatchForm.controls['endDate'].value;
      batchDetails.candidateDetails=this.data;

      //Upload+Save Lab details File---------------------------------------------------

      let batchName=batchDetails.batchName;//+"_"+batchDetails.location+"_"+batchDetails.subLocation+"_"+batchDetails.joiningDate;
      this.adminService
      .uploadAndSaveBatchDetails(batchDetails,this.selectedFile,batchName)
      .subscribe((res)=>{
          this.batchSaved=res;
      }); 
      console.log(this.batchSaved); 
    }
    
  }

  founded:string;
  focusOutFunction(batchName:string)
  {
    console.log(batchName);
    console.log("Focus out");
    let result:string="";
    this.adminService.checkBatchName(batchName).subscribe((res)=>{
        this.founded=res;
    });
  }
  focusInFunction()
  {
    console.log("focus in");
    this.founded=null;
  }
  show()
  {
    console.log(this.founded)
  }
  ngOnInit() 
  {
    console.log("Init called");
    if(this.founded=="0")
    {
      alert("Founded");
    }
  }

}

import { Injectable, OnInit } from '@angular/core';
import {UploadTestDetails} from '../models/uploadTestDetails';
import * as XLSX from 'xlsx';
//import { Http } from '@angular/http';
import { Batch } from '../models/batch';
import { Http, Response, RequestOptions,Headers } from '@angular/http';
import { map, catchError } from 'rxjs/operators';
import { Candidate } from '../models/candidate';



@Injectable({
  providedIn: 'root'
})
export class AdminService implements OnInit {

  
  UploadAndSaveMptDetailsURL="/api/mpt-set/upload-store";
  uploadAndSaveBatchDetailsURL="/api/batch/upload-store";
  getUploadedSetsURL="/api/getAllMpts";
  testPaperUploadURL="/api/file-upload";
  getBatcheURL="/api/get-batch";
  findBatchId="/api/checkBatchId";
  getCandidateBasedOnBatchNameURL="/api/getCandidates";
  saveCandidateData="/api/store-candidates"
  findCountOfBatches:string="/api/findBatchCount";
  count:number;
  constructor(private http:Http) {
     /*
    //find batch count
     this.findCountOfBatchCollection()
     .subscribe((res)=>{  
      this.count=res;
      
   });*/
  }
  
  ngOnInit(){
   
  }
  
  //-------------------validation of batch ID existence----------------------------------/
  checkBatchId(batchId:string,location:string,subLocation:string)
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    
    let options = new RequestOptions({ headers: myHeaders});
    let queryString:string='?batchId='+batchId;//+"&location="+location+"&subLocation="+subLocation;
    return this.http.get(this.findBatchId+queryString,options)
                    .pipe(map((response : Response) => {
                                  return response.json() as string;   
                                    }));
  }

  //----------------------Upload Files and save batch details  sets----------------------/

  // 1. upload and save batch details
  batchId:string;
  uploadAndSaveBatchDetails(batchDetails:Batch,selectedFile:File,candidateData:Candidate[])
  {

    // //create batch id
    // this.batchId=batchDetails.location+"_"+batchDetails.subLocation+"_"+(this.count+Math.floor(Math.random()*1000));
    // batchDetails._id=this.batchId;

    this.batchId=batchDetails._id;

    //batchId in candidate table
    candidateData=this.assignCandidateID(candidateData);

    const uploadBatchData = new FormData();
    uploadBatchData.append('myFile',selectedFile, selectedFile.name);
    uploadBatchData.append('fileName',batchDetails.batchName);
    uploadBatchData.append('candidateData',JSON.stringify(candidateData));
    uploadBatchData.append('batchDetailsModel',JSON.stringify(batchDetails));
     return this.http.post(this.uploadAndSaveBatchDetailsURL, uploadBatchData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as Batch;   
      }));
    
  }


//----------------------Upload Files and save test details----------------------/
  uploadAndSaveMpt(uploadTestDetails:UploadTestDetails,selectedFile:File,testPaperSetName:string)
  {
    
    const uploadMptData = new FormData();
    uploadMptData.append('myFile',selectedFile, selectedFile.name);
    uploadMptData.append('fileName',testPaperSetName);
    uploadMptData.append('uploadTestDetailsModel',JSON.stringify(uploadTestDetails));
     return this.http.post(this.UploadAndSaveMptDetailsURL, uploadMptData)
     .pipe( 
       map((response : Response) => 
       {
          return response.json() as UploadTestDetails;   
      }));
    
  }
  

  
/**********************************GEt data from db*********************************** */

    
//----------------------get uploaded mpts----------------------/
  getUploadedPaperSets()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getUploadedSetsURL,options)
    .pipe(map((response : Response) => {
        return response.json() as UploadTestDetails[];   
    }));
  }
  

  //----------------------get added batches ----------------------/
  getBatch()
  {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: myHeaders});
  
    return this.http.get(this.getBatcheURL,options)
    .pipe(map((response : Response) => {
        return response.json() as Batch[];   
    }));
  }

  //----------------------get candidates----------------------/

    //Based on batch name : //have to modify
    getCandidateBasedOnBatchName(batchId:string)
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});
      console.log(batchId);
      let queryString:string="?batchId="+batchId;

      return this.http.get(this.getCandidateBasedOnBatchNameURL+queryString,options)
      .pipe(map((response : Response) => {
          return response.json() as Candidate[];    //have to modify
      }));
      
    }

    


  //--------------------------------------Find count of Batches----------------
    findCountOfBatchCollection()
    {
      let myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: myHeaders});

      return this.http.get(this.findCountOfBatches,options)
      .pipe(map((response : Response) => {
          return response.json() as number;    //have to modify
      }));
    }

    assignCandidateID(candidate:Candidate[]):Candidate[]
    {
        for(let i=0;i<candidate.length;i++)
        {
          candidate[i].batchId=this.batchId;
        }
        return candidate;
    }



  private handleError (error: any): Promise<any> 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console
    return Promise.reject(errMsg);
  }
  



}

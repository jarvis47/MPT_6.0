export class TestJSON
{
    srNo:string;  
    testPaperSet:string;
    dateOfAssignment:Date;
    userName:string;
    userId:string;
    emailAddress:string;
    ipAddress:string;
}
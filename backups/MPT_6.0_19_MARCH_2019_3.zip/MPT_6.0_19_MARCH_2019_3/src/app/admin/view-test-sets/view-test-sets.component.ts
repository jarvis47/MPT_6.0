import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { UploadTestDetails } from '../../models/uploadTestDetails';
import { Batch } from '../../models/batch';

@Component({
  selector: 'app-view-test-sets',
  templateUrl: './view-test-sets.component.html',
  styleUrls: ['./view-test-sets.component.css']
})
export class ViewTestSetsComponent implements OnInit {

  constructor(private adminService:AdminService) { }
  paperSets:UploadTestDetails[];
  selectedBatchName:Batch;
  selectedTestType:string;
  batches:Batch[];
  ngOnInit() {
    this.adminService.getBatch("Chennai","SIPCOT")
    .subscribe((res)=>{
      this.batches=res;
    });

  }
  onSelectingBatch(batch:Batch)
  {
    
  }
  onSelectingTestType(testType)
  {
    this.adminService
    .getUploadedPaperSets(this.selectedBatchName._id,testType)
    .subscribe((data)=>{
        this.paperSets=data;
    });   
  }
 
}
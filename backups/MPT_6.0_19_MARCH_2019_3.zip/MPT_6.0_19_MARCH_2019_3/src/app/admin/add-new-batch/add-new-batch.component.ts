import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '../../../../node_modules/@angular/forms';
import { Candidate } from '../../models/candidate';
import { Batch } from '../../models/batch';

import * as XLSX from 'xlsx';
import { AdminService } from '../../services/admin.service';
import { FileUploadedModel } from '../../models/file-uploaded-model';

type AOA = any[][];

@Component({
  selector: 'app-add-new-batch',
  templateUrl: './add-new-batch.component.html',
  styleUrls: ['./add-new-batch.component.css']
})
export class AddNewBatchComponent implements OnInit {

  fileUploaded:FileUploadedModel;
  batchSaved:Batch;
  candidateDataSaved:Candidate[];
  batchFounded:string;
  addNewBatchForm:FormGroup;
  data: Candidate[];
	wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
	fileName: string = 'SheetJS.xlsx';
  selectedFile:File;

  constructor(private adminService:AdminService, ) 
  {
    console.log("const called");
    this.addNewBatchForm=new FormGroup({
      selectedLocation:new FormControl(""),
      selectedSubLocation:new FormControl(""),
      batchId:new FormControl(""),
      batchName:new FormControl(""),
      lotName:new FormControl(""),
      onBoardingDate:new FormControl(""),
      endDate:new FormControl(""),
      selectedStudentFile:new FormControl("")
    })
   }

   /*************************Reading excel*******************************/
  excelData:Candidate[];
  fileTypeMessage:boolean=false;
  fileSelected:boolean=false;

  
  onFileSelect(evt)
  {
    this.fileSelected=true;
    this.selectedFile=evt.target.files[0] ;
    let extension:string[]=this.selectedFile.name.toLowerCase().split('.');
    console.log((extension[extension.length-1]!="xlsx"));
    
    //Validation of file select

    // if(extension[extension.length-1].trim()!="xlsx")
    // {
    //   this.fileTypeMessage=true;
    // }
    // else if(extension[extension.length-1].trim()!="xls")
    // {
    //   this.fileTypeMessage=true;
    // }

    // if(!this.fileTypeMessage)
    // {
      this.fileSelected=true;
      console.log("inside file upload")
      this.fileTypeMessage=false;
      // wire up file reader 
      const target: DataTransfer = <DataTransfer>(evt.target);
      if (target.files.length !== 1) throw new Error('Cannot use multiple files');
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        // read workbook 
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        // grab first sheet 
        const wsname: string = wb.SheetNames[0];
      
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        // save data 
        this.excelData = <Candidate[]>(XLSX.utils.sheet_to_json(ws, { header: 0 }));
        
        };
        reader.readAsBinaryString(target.files[0]);
  //    }
      
  }
  

  // clearFile()
  // {
  //   this.fileTypeMessage=false;
  //   this.fileSelected=false;
  // }

  
  onSubmit()
  {
   
      let invalidDate:boolean;

      let batchDetails = new Batch();
      batchDetails.location=this.addNewBatchForm.controls['selectedLocation'].value;
      batchDetails.subLocation=this.addNewBatchForm.controls['selectedSubLocation'].value;
      batchDetails._id=this.addNewBatchForm.controls['batchId'].value;
      batchDetails.batchName=this.addNewBatchForm.controls['batchName'].value;
      batchDetails.lotName=this.addNewBatchForm.controls['lotName'].value;
      let joiningDate=this.addNewBatchForm.controls['onBoardingDate'].value;
      batchDetails.joiningDate=joiningDate;
      let endDate=this.addNewBatchForm.controls['endDate'].value;
      batchDetails.endDate=endDate;
      //batchDetails.candidateDetails=this.excelData;

      //Validate of date
      joiningDate=new Date(joiningDate);
      endDate=new Date(endDate);
      let alertMessage:string;

      if(endDate<new Date())
      {
        invalidDate=true;
        alertMessage="End Date can't be less than today's date";
      }
      else if(endDate<joiningDate)
      {
        invalidDate=true;
        alertMessage="End Date can't be less than joining date"
      }
      else if(joiningDate>new Date())
      {
        invalidDate=true;
        alertMessage="You have entered joining date greater than today's dates";
      }
      else
      {
        invalidDate = false;
      }

     
      //Validation of batch exists
      this.checkBatchIdExistence(batchDetails._id,batchDetails.location,batchDetails.subLocation);

      console.log("Batch Founded: "+this.batchFounded);
      if(this.batchFounded=="0" || this.batchFounded==undefined)
      {
        alert("Batch with the same ID already Exists");
        return false;
      }
      else if(invalidDate)
      {
        alert(alertMessage);
        return false;
      }
    else 
    {
      let confirmBox=confirm("Do You want to add : "+batchDetails._id+" Batch");
      if(confirmBox)
      {
        //Upload+Save Lab details File---------------------------------------------------

      
        this.adminService
          .uploadAndSaveBatchDetails(batchDetails, this.selectedFile,this.excelData)
          .subscribe((res) => {
            this.batchSaved = res;
          });
        
         
        window.location.reload();
      }    
    }
  }

  //Checking existence of batch ID in DB

  checkBatchIdExistence(batchId:string,location:string,subLocation:string)
  {
    if(batchId!=undefined && location!=undefined && subLocation!=undefined)
    {
      console.log("checking db for batch exists");
      this.adminService.checkBatchId(batchId,location,subLocation).subscribe((res)=>{
          this.batchFounded=res;
      });  
    }
  }

  locationSelected:string;
  batchIdSelected:string;
  subLocationSelected:string;
  onSelectionLocation(location)
  {
    this.locationSelected=location;
    this.checkBatchIdExistence(this.batchIdSelected,this.locationSelected,this.subLocationSelected);
  }
  
 
  onSelectionSubLocation(subLocation)
  {
    this.subLocationSelected=subLocation;
    this.checkBatchIdExistence(this.batchIdSelected,this.locationSelected,this.subLocationSelected);
  }


  onSelectionBatchId(batchId)
  {
    console.log("batchId changed");
    this.batchIdSelected=batchId;
    this.checkBatchIdExistence(this.batchIdSelected,this.locationSelected,this.subLocationSelected);
  }



  ngOnInit() 
  {
    
  }

}
